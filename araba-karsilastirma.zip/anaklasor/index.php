<!doctype html>
<html lang="tr">
<title>Anasayfa</title>
<?php include("./assets/head.php")?>
<?php include("./assets/nav.php")?>
<body class="">
 

<?php include("./assets/alert.php"); ?>
    <div class="container-fluid">
        <div class="card">
            <div class="card-header">
                Araç Karşılaştır
            </div>
            <div class="card-body">
                <h5 class="card-title">Araç Karşılaştırma Sitesine Hoş Geldiniz...</h5>
            </div>
        </div>
    </div>


<?php 
include("./assets/footer.php");
include("./assets/script.php")
?>

</body>

</html>