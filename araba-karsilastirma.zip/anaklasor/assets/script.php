
    <!-- SCRIPT START-->
    <script src="../eklentiler/jquery/jquery.min.js"></script>
    <script src="../eklentiler/jquery/jquery.cookie.js"></script>
    <script src="../eklentiler/boostrap/js/bootstrap.min.js"></script>
    <script src="../eklentiler//sweet-alert/sweetalert.min.js"></script>

    <!-- SCRIPT END-->