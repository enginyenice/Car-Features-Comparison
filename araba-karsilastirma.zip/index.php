<?php

header("Location: anaklasor/giris.php");
//header("Location: /anaklasor/giris.php"); 
?>